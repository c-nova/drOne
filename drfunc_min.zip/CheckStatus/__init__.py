import azure.functions as func
import json
import logging
import os
import sys

# 親ディレクトリをパスに追加してsharedモジュールをインポート
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from shared.database import ResearchJobManager
from shared.auth import get_current_user
from shared.settings import get_config

# Azure AI Foundry imports
from azure.ai.projects import AIProjectClient
from azure.identity import DefaultAzureCredential


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('CheckStatus function processed a request.')
    try:
        # URLパラメータからjob_idを取得
        job_id = req.route_params.get('job_id')
        if not job_id:
            return func.HttpResponse(
                json.dumps({"error": "Job ID is required"}),
                status_code=400,
                headers={"Content-Type": "application/json"}
            )

        # 認証
        principal = get_current_user(req)
        if principal is None:
            return func.HttpResponse(
                json.dumps({"error": "Unauthorized"}),
                status_code=401,
                headers={"Content-Type": "application/json"}
            )

        # ジョブの詳細を取得
        job_manager = ResearchJobManager()
        job = job_manager.get_job(job_id)
        if not job:
            return func.HttpResponse(
                json.dumps({"error": "Job not found"}),
                status_code=404,
                headers={"Content-Type": "application/json"}
            )

        logging.info(f"Checking status for job {job_id}: {job['status']}")

        # 所有者チェック（anonymousはスキップ）
        req_user = principal.get('user_id', 'anonymous')
        if job.get('user_id') not in (req_user, None, 'anonymous') and (get_config('STRICT_OWNER_CHECK', 'true') or 'true').lower() == 'true':
            return func.HttpResponse(
                json.dumps({"error": "Forbidden"}),
                status_code=403,
                headers={"Content-Type": "application/json"}
            )

        # Azure AI Foundryでのステータス確認（run_idがある場合）
        messages_data = None
        if job.get('run_id'):
            try:
                project_endpoint = get_config("PROJECT_ENDPOINT")
                if project_endpoint:
                    project = AIProjectClient(
                        endpoint=project_endpoint,
                        credential=DefaultAzureCredential()
                    )
                    # Runの状態を確認
                    run = project.agents.runs.get(
                        thread_id=job['thread_id'],
                        run_id=job['run_id']
                    )
                    logging.info(f"Run status: {run.status}")

                    # REST APIでmessages取得
                    import requests
                    api_version = "v1"
                    foundry_endpoint = project_endpoint.rstrip("/")
                    url = f"{foundry_endpoint}/threads/{job['thread_id']}/messages?api-version={api_version}"
                    token = DefaultAzureCredential().get_token("https://ai.azure.com/.default").token
                    headers = {
                        "Authorization": f"Bearer {token}",
                        "Content-Type": "application/json"
                    }
                    response = requests.get(url, headers=headers)
                    messages_data = []
                    try:
                        resp_json = response.json()
                        msg_list = resp_json.get("data", [])
                        for msg in msg_list:
                            msg_dict = {
                                'id': msg.get('id'),
                                'role': msg.get('role'),
                                'created_at': msg.get('created_at'),
                                'content': []
                            }
                            for content_item in msg.get('content', []):
                                if 'text' in content_item:
                                    msg_dict['content'].append(content_item['text'].get('value', ''))
                                    annotations = content_item['text'].get('annotations', [])
                                    if annotations:
                                        msg_dict['annotations'] = annotations
                                    for ann in annotations:
                                        if ann.get('type') == 'url_citation':
                                            url_ = ann.get('url')
                                            title_ = ann.get('title')
                                            if url_:
                                                msg_dict.setdefault('citations', []).append({'url': url_, 'title': title_})
                                if 'source' in content_item:
                                    msg_dict.setdefault('sources', []).append(content_item['source'])
                                if 'url' in content_item:
                                    msg_dict.setdefault('urls', []).append(content_item['url'])
                                if 'reference' in content_item:
                                    msg_dict.setdefault('references', []).append(content_item['reference'])
                            messages_data.append(msg_dict)
                    except Exception as ex:
                        logging.error(f"Error parsing messages API response: {ex}")
                        return func.HttpResponse(
                            json.dumps({"error": f"Error parsing messages API response: {str(ex)}"}),
                            status_code=500,
                            headers={"Content-Type": "application/json"}
                        )

                    # Run statusに基づいてジョブステータスを更新
                    if getattr(run, 'status', None) == "completed":
                        assistant_messages = [m for m in msg_list if m.get('role') == "assistant"] if 'msg_list' in locals() else []
                        if assistant_messages:
                            latest_message = assistant_messages[0]
                            content = "\n".join([
                                c['text']['value']
                                for c in latest_message.get('content', [])
                                if 'text' in c and 'value' in c['text']
                            ])
                            job_manager.update_job_result(job_id, content.strip())
                            job_manager.add_job_step(job_id, 'completed', 'Deep Research調査が完了しました')
                            job_manager.update_job_status(job_id, 'completed', 'Deep Research調査が完了しました')
                            job = job_manager.get_job(job_id)
                    elif getattr(run, 'status', None) in ["failed", "expired"]:
                        error_msg = f"Research failed with status: {run.status}"
                        job_manager.update_job_error(job_id, error_msg)
                        job_manager.add_job_step(job_id, 'failed', error_msg)
                        job = job_manager.get_job(job_id)
                    elif getattr(run, 'status', None) in ["queued", "in_progress", "requires_action"]:
                        current_step = f"Deep Research実行中... (Status: {run.status})"
                        job_manager.update_job_status(job_id, 'in_progress', current_step)
                        job = job_manager.get_job(job_id)
                        if getattr(run, 'status', None) == "requires_action":
                            job_manager.add_job_step(job_id, 'requires_action', 'アクションが必要です')
            except Exception as e:
                logging.error(f"Error checking run status: {str(e)}")
                # 続行（基本情報は返す）

        # ジョブステップも取得
        steps = job_manager.get_job_steps(job_id)

        # レスポンスデータを構築
        def ensure_z(dt):
            if dt and isinstance(dt, str) and not dt.endswith('Z'):
                return dt + 'Z'
            return dt

        response_data = {
            "job_id": job_id,
            "status": job['status'],
            "query": job['query'],
            "current_step": job['current_step'],
            "created_at": ensure_z(job['created_at']),
            "completed_at": ensure_z(job['completed_at']),
            "steps": steps,
            "has_result": bool(job['result']),
            "has_error": bool(job['error_message']),
            "error_message": job['error_message'],
            "thread_id": job.get('thread_id'),
            "run_id": job.get('run_id'),
            "messages": messages_data
        }

        return func.HttpResponse(
            json.dumps(response_data),
            status_code=200,
            headers={"Content-Type": "application/json"}
        )
    except Exception as e:
        logging.error(f"Error in CheckStatus function: {str(e)}")
        return func.HttpResponse(
            json.dumps({"error": str(e)}),
            status_code=500,
            headers={"Content-Type": "application/json"}
        )
