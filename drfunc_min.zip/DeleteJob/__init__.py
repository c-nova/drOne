import azure.functions as func
import json
import logging
import os
import sys

# 親ディレクトリをパスに追加してsharedモジュールをインポート
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from shared.database import ResearchJobManager
from shared.auth import get_current_user
from shared.settings import get_config

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('DeleteJob function processed a request.')
    try:
        principal = get_current_user(req)
        if principal is None:
            return func.HttpResponse(
                json.dumps({"error": "Unauthorized"}),
                status_code=401,
                headers={"Content-Type": "application/json"}
            )

        job_id = req.route_params.get('job_id')
        if not job_id:
            return func.HttpResponse(
                json.dumps({"error": "Job ID is required"}),
                status_code=400,
                headers={"Content-Type": "application/json"}
            )

        job_manager = ResearchJobManager()
        job = job_manager.get_job(job_id)
        if not job:
            return func.HttpResponse(
                json.dumps({"error": "Job not found"}),
                status_code=404,
                headers={"Content-Type": "application/json"}
            )

        # 所有者チェック
        req_user = principal.get('user_id', 'anonymous')
        if job.get('user_id') not in (req_user, None, 'anonymous') and (get_config('STRICT_OWNER_CHECK', 'true') or 'true').lower() == 'true':
            return func.HttpResponse(
                json.dumps({"error": "Forbidden"}),
                status_code=403,
                headers={"Content-Type": "application/json"}
            )

        job_manager.delete_job(job_id)
        return func.HttpResponse(
            json.dumps({"success": True, "message": f"Job {job_id} deleted"}),
            status_code=200,
            headers={"Content-Type": "application/json"}
        )
    except Exception as e:
        logging.error(f"Error in DeleteJob function: {str(e)}")
        return func.HttpResponse(
            json.dumps({"error": str(e)}),
            status_code=500,
            headers={"Content-Type": "application/json"}
        )
