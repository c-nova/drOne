import os
from typing import Optional

from azure.identity import DefaultAzureCredential
try:
    from azure.keyvault.secrets import SecretClient
except Exception:
    SecretClient = None  # package may not be installed yet for local only


def _get_kv_client():
    """Return a SecretClient if KEY_VAULT_URI is configured and package is available."""
    kv_uri = os.getenv("KEY_VAULT_URI")
    if not kv_uri or SecretClient is None:
        return None
    try:
        cred = DefaultAzureCredential()
        return SecretClient(vault_url=kv_uri, credential=cred)
    except Exception:
        return None


def get_secret(name: str, default: Optional[str] = None) -> Optional[str]:
    """Get a secret by name with Key Vault-first strategy.

    Notes:
    - Azure Key Vault secret names don't allow underscores. If a lookup by the
      provided name fails, we also try the dashed variant ("_" -> "-").
    - Falls back to environment variable for local/dev.
    """
    client = _get_kv_client()
    if client:
        # Try as-is
        try:
            return client.get_secret(name).value
        except Exception:
            # Try dashed variant if different
            dashed = name.replace('_', '-')
            if dashed != name:
                try:
                    return client.get_secret(dashed).value
                except Exception:
                    pass
    # Fallback to environment
    return os.getenv(name, default)


def get_config(name: str, default: Optional[str] = None) -> Optional[str]:
    """Alias for get_secret for now; kept for readability."""
    return get_secret(name, default)
