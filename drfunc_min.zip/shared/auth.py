import base64
import json
import os
from typing import Optional, Dict, Any
from .settings import get_config


def _b64url_decode(data: str) -> bytes:
    # SWA header is base64url without padding sometimes
    padding = '=' * ((4 - len(data) % 4) % 4)
    return base64.urlsafe_b64decode(data + padding)


def get_current_user(req) -> Optional[Dict[str, Any]]:
    """Parse Azure Static Web Apps authentication header.

    Returns a dict like {"user_id": str, "identity_provider": str, "user_details": str, "roles": [..]} or None.
    """
    principal_b64 = req.headers.get('x-ms-client-principal') or req.headers.get('X-MS-CLIENT-PRINCIPAL')
    if not principal_b64:
        # allow anonymous if flagged (KV優先)
        if (get_config('ALLOW_ANONYMOUS', 'true') or 'true').lower() == 'true':
            return {"user_id": "anonymous", "roles": ["anonymous"]}
        return None
    try:
        data = json.loads(_b64url_decode(principal_b64).decode('utf-8'))
        user_id = data.get('userId') or data.get('user_id') or data.get('claims', [{}])[0].get('val')
        # Normalize fields
        return {
            "user_id": user_id or "anonymous",
            "identity_provider": data.get('identityProvider'),
            "user_details": data.get('userDetails'),
            "roles": data.get('userRoles', [])
        }
    except Exception:
        if (get_config('ALLOW_ANONYMOUS', 'true') or 'true').lower() == 'true':
            return {"user_id": "anonymous", "roles": ["anonymous"]}
        return None
